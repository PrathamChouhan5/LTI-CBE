# driver.py

import importlib.util
import datetime
import ast

# -------------------------------------------------
# SAFE NUMPY IMPORT
# -------------------------------------------------

try:
    import numpy as np
except ImportError:
    print("NumPy not available in execution environment", flush=True)
    exit(0)

# -------------------------------------------------
# CONFIGURATION
# -------------------------------------------------

ASSESSMENT_NAME = "Sensor Analyzer Assessment"
LOG_FILE = "test_report.log"

TEST_COUNTER = 0
RESULT_LINES = []

# -------------------------------------------------
# LOGGING (ONLY AT FINAL OUTPUT)
# -------------------------------------------------

def log(message: str):
    print(message, flush=True)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(message + "\n")
    except Exception:
        pass

# -------------------------------------------------
# HARD-CODE / STUB DETECTION
# -------------------------------------------------

def detect_hardcode_or_stub(func_node: ast.FunctionDef) -> bool:
    if not func_node.body:
        return True

    for stmt in func_node.body:
        if isinstance(stmt, ast.Pass):
            return True

    if len(func_node.body) == 1 and isinstance(func_node.body[0], ast.Return):
        val = func_node.body[0].value
        if isinstance(val, (ast.Constant, ast.List, ast.Dict, ast.Tuple)):
            return True

    return False

# -------------------------------------------------
# TEST RESULT RECORDER (NO PRINTING)
# -------------------------------------------------

def record(passed, title, visibility="Visible"):
    global TEST_COUNTER
    TEST_COUNTER += 1

    status = "Passed" if passed else "Failed"
    RESULT_LINES.append(
        f"{visibility} Test Case {TEST_COUNTER} {status}: {title}"
    )

# -------------------------------------------------
# DRIVER
# -------------------------------------------------

def test_student_code(solution_path: str):

    # Reset log file
    try:
        open(LOG_FILE, "w").close()
    except Exception:
        pass

    header = (
        f"=== {ASSESSMENT_NAME} Test Run at "
        f"{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ==="
    )

    # ---------------- AST INSPECTION ----------------

    try:
        with open(solution_path, "r", encoding="utf-8") as f:
            source = f.read()
        tree = ast.parse(source)
    except Exception:
        log(header)
        log("Visible Test Case 1 Failed: Unable to read or parse solution")
        return

    bad_functions = set()
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == "SensorAnalyzer":
            for fn in node.body:
                if isinstance(fn, ast.FunctionDef) and fn.name != "__init__":
                    if detect_hardcode_or_stub(fn):
                        bad_functions.add(fn.name)

    # ---------------- LOAD MODULE ----------------

    try:
        spec = importlib.util.spec_from_file_location(
            "student_solution", solution_path
        )
        student_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(student_module)
    except Exception:
        log(header)
        log("Visible Test Case 1 Failed: Runtime error while loading solution")
        return

    if not hasattr(student_module, "SensorAnalyzer"):
        log(header)
        log("Visible Test Case 1 Failed: SensorAnalyzer class not found")
        return

    sa = student_module.SensorAnalyzer()

    # ---------------- TEST CASES (EXACTLY 9) ----------------

    try:
        res = sa.create_sensor_array([23.5, 45.0, 17.3, 32.1])
        record(
            isinstance(res, np.ndarray)
            and np.allclose(res, [23.5, 45.0, 17.3, 32.1]),
            "Create Sensor Array",
        )
    except Exception:
        record(False, "Create Sensor Array")

    try:
        res = sa.validate_sensor_array(np.array([25, -10, 40]))
        record(res is False, "Validate Sensor Array (Negative)")
    except Exception:
        record(False, "Validate Sensor Array (Negative)")

    try:
        res = sa.validate_sensor_array(np.array([10, 20, 30]))
        record(res is True, "Validate Sensor Array (Positive)")
    except Exception:
        record(False, "Validate Sensor Array (Positive)")

    try:
        res = sa.compute_sensor_statistics(np.array([10.5, 25.0, 40.5]))
        record(
            isinstance(res, tuple)
            and np.isclose(res[0], 76.0)
            and round(res[1], 1) == 25.3
            and res[2] == 40.5,
            "Compute Sensor Statistics",
        )
    except Exception:
        record(False, "Compute Sensor Statistics")

    try:
        res = sa.filter_extreme_readings(np.array([40, 50, 60]))
        record(
            np.allclose(res, [40.0, 45.0, 54.0]),
            "Filter Extreme Readings",
        )
    except Exception:
        record(False, "Filter Extreme Readings")

    try:
        res = sa.label_high_sensors(np.array([30, 60, 15]))
        record(
            isinstance(res, np.ndarray)
            and list(res) == ["Normal", "High", "Normal"],
            "Label High Sensors",
        )
    except Exception:
        record(False, "Label High Sensors")

    try:
        res = sa.format_sensor_readings(np.array([22.0, 35.75]))
        record(
            list(res) == ["22.00 units", "35.75 units"],
            "Format Sensor Readings",
            visibility="Hidden",
        )
    except Exception:
        record(False, "Format Sensor Readings", "Hidden")

    try:
        res = sa.validate_sensor_array(np.array([]))
        record(
            res is False,
            "Validate Empty Sensor Array",
            visibility="Hidden",
        )
    except Exception:
        record(False, "Validate Empty Sensor Array", "Hidden")

    try:
        res = sa.filter_extreme_readings(np.array([50.0]))
        record(
            np.allclose(res, [45.0]),
            "Filter Boundary Reading",
            visibility="Hidden",
        )
    except Exception:
        record(False, "Filter Boundary Reading", "Hidden")

    # ---------------- HARD-CODE PENALTY (DOWNGRADE ONLY) ----------------

    FINAL_RESULTS = []

    for line in RESULT_LINES:
        downgraded = False
        for fn in bad_functions:
            if fn.replace("_", " ").lower() in line.lower() and "Passed" in line:
                FINAL_RESULTS.append(
                    line.replace("Passed", "Failed")
                    + " | Reason: Hardcoded or stub implementation"
                )
                downgraded = True
                break
        if not downgraded:
            FINAL_RESULTS.append(line)

    # ---------------- FINAL OUTPUT (PRINT ONCE) ----------------

    log(header)
    for line in FINAL_RESULTS:
        log(line)

# -------------------------------------------------
# ENTRY POINT
# -------------------------------------------------

if __name__ == "__main__":
    test_student_code("solution.py")
