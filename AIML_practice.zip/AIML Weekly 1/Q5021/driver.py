# driver.py
"""
Deterministic driver for Flight Delay Analyzer assessment (updated).

Changes vs prior version:
- More flexible keyword validation: each required "keyword" may be a list of alternative tokens;
  the check passes if any alternative appears in the student's source.
  This avoids false negatives for filter_high_delays where students use ">=" or ".loc" etc.
- Otherwise follows the Attendance-style deterministic driver:
  * Deterministic visible + hidden test cases
  * Simple hardcoding / 'pass' detection
  * Writes results to test_report.log
  * No randomized inputs
"""

import importlib.util
import datetime
import os
import pandas as pd
import inspect
import traceback

def test_student_code(solution_path):
    report_dir = os.path.join(os.path.dirname(__file__))
    report_path = os.path.join(report_dir, "test_report.log")
    os.makedirs(report_dir, exist_ok=True)

    # import student module
    spec = importlib.util.spec_from_file_location("student_module", solution_path)
    student_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(student_module)

    # instantiate expected class
    try:
        analyzer = student_module.FlightDelayAnalyzer()
    except Exception as e:
        msg = f"\n=== Flight Delay Analyzer Test Run at {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ===\n"
        msg += f"Error: Could not instantiate FlightDelayAnalyzer: {e}\n"
        print(msg)
        with open(report_path, "a", encoding="utf-8") as f:
            f.write(msg)
        return

    report_lines = [f"\n=== Flight Delay Analyzer Test Run at {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ==="]

    # Deterministic visible test cases
    visible_cases = [
        {
            "desc": "Create Flight Log DataFrame",
            "func": "create_flight_log_df",
            "input": [[301, "AI", "DEL-MUM", 30],
                      [302, "AI", "DEL-BLR", 60],
                      [303, "6E", "DEL-MUM", 10]],
            "expected": pd.DataFrame([[301, "AI", "DEL-MUM", 30],
                                      [302, "AI", "DEL-BLR", 60],
                                      [303, "6E", "DEL-MUM", 10]],
                                     columns=["FlightID", "AirlineCode", "Route", "Delay"])
        },
        {
            "desc": "Create Airline Master DataFrame",
            "func": "create_airline_master_df",
            "input": [["AI", "Air India"], ["6E", "IndiGo"]],
            "expected": pd.DataFrame([["AI", "Air India"], ["6E", "IndiGo"]], columns=["AirlineCode", "AirlineName"])
        },
        {
            "desc": "Merge Airline Names into Flight Log",
            "func": "merge_airline_names",
            "input": (pd.DataFrame([[301, "AI", "DEL-MUM", 30]], columns=["FlightID", "AirlineCode", "Route", "Delay"]),
                      pd.DataFrame([["AI", "Air India"]], columns=["AirlineCode", "AirlineName"])),
            "expected": pd.DataFrame([[301, "AI", "DEL-MUM", 30, "Air India"]],
                                     columns=["FlightID", "AirlineCode", "Route", "Delay", "AirlineName"])
        },
        {
            "desc": "Average Delay by Airline",
            "func": "average_delay_by_airline",
            "input": pd.DataFrame([[301, "AI", "DEL-MUM", 30, "Air India"],
                                   [302, "AI", "DEL-BLR", 60, "Air India"],
                                   [303, "6E", "DEL-MUM", 10, "IndiGo"]],
                                  columns=["FlightID", "AirlineCode", "Route", "Delay", "AirlineName"]),
            "expected": pd.DataFrame({"AirlineName": ["Air India", "IndiGo"], "Average Delay": [45.0, 10.0]})
        },
        {
            "desc": "Filter High Delays (>40)",
            "func": "filter_high_delays",
            "input": (pd.DataFrame([[301, "AI", "DEL-MUM", 30],
                                   [302, "AI", "DEL-BLR", 60]],
                                  columns=["FlightID", "AirlineCode", "Route", "Delay"]), 40),
            "expected": pd.DataFrame([[302, "AI", "DEL-BLR", 60]], columns=["FlightID", "AirlineCode", "Route", "Delay"])
        },
        {
            "desc": "Most Delayed Route",
            "func": "most_delayed_route",
            "input": pd.DataFrame([[301, "AI", "DEL-MUM", 30],
                                   [302, "AI", "DEL-BLR", 60],
                                   [303, "6E", "DEL-BLR", 60]],
                                  columns=["FlightID", "AirlineCode", "Route", "Delay"]),
            "expected": pd.DataFrame([["DEL-BLR", 60.0]], columns=["Route", "Average Delay"])
        }
    ]

    # Deterministic hidden cases
    hidden_cases = [
        {
            "desc": "Merge preserves flights with unknown airline codes",
            "func": "merge_airline_names",
            "input": (pd.DataFrame([[401, "XX", "DEL-CCU", 15],
                                   [402, "AI", "DEL-MUM", 45]],
                                  columns=["FlightID", "AirlineCode", "Route", "Delay"]),
                      pd.DataFrame([["AI", "Air India"]], columns=["AirlineCode", "AirlineName"])),
            "expected": pd.DataFrame([[401, "XX", "DEL-CCU", 15, pd.NA],
                                      [402, "AI", "DEL-MUM", 45, "Air India"]],
                                     columns=["FlightID", "AirlineCode", "Route", "Delay", "AirlineName"])
        },
        {
            "desc": "Most Delayed Route with tie-break returns one row",
            "func": "most_delayed_route",
            "input": pd.DataFrame([[501, "AI", "A-B", 30],
                                   [502, "AI", "B-C", 50],
                                   [503, "AI", "A-B", 70],
                                   [504, "AI", "B-C", 70]],
                                  columns=["FlightID", "AirlineCode", "Route", "Delay"]),
            "expected_func": lambda df: (df.groupby("Route")["Delay"].mean().reset_index().rename(columns={"Delay":"Average Delay"})
                                         .sort_values("Average Delay", ascending=False).head(1).reset_index(drop=True))
        }
    ]

    # Flexible keyword checks:
    # each entry is a list of alternative tokens; at least one alternative must appear.
    keyword_checks = {
        "create_flight_log_df": [["pd.dataframe"], ["columns"]],
        "create_airline_master_df": [["pd.dataframe"], ["columns"]],
        "merge_airline_names": [["merge"], ["pd.merge"]],
        "average_delay_by_airline": [["groupby"], ["mean"], ["reset_index", "resetindex"]],
        # filter_high_delays: accept '>' or '>=' or '.loc' or boolean indexing 'df[...'] or '.query'
        "filter_high_delays": [["delay"], [">", ">=", ".loc", "df[" , "df[\"", "query"]],
        "most_delayed_route": [["groupby"], ["mean"], ["sort_values"], ["head"]]
    }

    def detect_hardcoded_or_pass(src, expected):
        flat = src.replace(" ", "").replace("\n", "").lower()
        if "pass" in flat:
            return True
        try:
            if isinstance(expected, pd.DataFrame):
                exp_flat = str(expected.reset_index(drop=True)).replace(" ", "").replace("\n", "").lower()
                if exp_flat in flat:
                    return True
        except Exception:
            pass
        return False

    def validate_keywords_flexible(src, requirement_groups):
        """
        requirement_groups: list of lists (alternatives).
        For each group, at least one alternative must appear in src (case-insensitive).
        Returns True if all groups satisfied.
        """
        src_lower = src.lower()
        for alternatives in requirement_groups:
            found = False
            for alt in alternatives:
                if alt.lower() in src_lower:
                    found = True
                    break
            if not found:
                return False
        return True

    # Run visible deterministic cases
    for i, case in enumerate(visible_cases, 1):
        try:
            func = getattr(analyzer, case["func"])
            src = inspect.getsource(func).lower()

            # Hardcoding / pass check
            if detect_hardcoded_or_pass(src, case["expected"]):
                msg = f" Visible Test Case {i} Failed: {case['desc']} | Reason: Hardcoded return or 'pass' found in source"
                report_lines.append(msg)
                print(msg)
                continue

            # Keyword validation (flexible)
            required = keyword_checks.get(case["func"], [])
            if required and not validate_keywords_flexible(src, required):
                msg = f" Visible Test Case {i} Failed: {case['desc']} | Reason: Missing required keyword groups {required}"
                report_lines.append(msg)
                print(msg)
                continue

            # Execute
            input_data = case["input"]
            result = func(input_data) if not isinstance(input_data, tuple) else func(*input_data)
            expected = case["expected"]

            # Compare DataFrames
            if isinstance(expected, pd.DataFrame):
                pd.testing.assert_frame_equal(result.reset_index(drop=True), expected.reset_index(drop=True), check_dtype=False)
            else:
                assert result == expected

            msg = f" Visible Test Case {i} Passed: {case['desc']}"
            report_lines.append(msg)
            print(msg)

        except AssertionError as ae:
            msg = f" Visible Test Case {i} Failed: {case['desc']} | AssertionError: {ae}"
            report_lines.append(msg)
            print(msg)
        except Exception as e:
            tb = traceback.format_exc()
            msg = f" Visible Test Case {i} Crashed: {case['desc']} | Error: {e}\n{tb}"
            report_lines.append(msg)
            print(msg)

    # Run hidden deterministic cases
    for j, case in enumerate(hidden_cases, 1):
        try:
            func = getattr(analyzer, case["func"])
            src = inspect.getsource(func).lower()

            if detect_hardcoded_or_pass(src, case.get("expected", "")):
                msg = f" Hidden Test Case {j} Failed: {case['desc']} | Reason: Hardcoded return or 'pass' found"
                report_lines.append(msg)
                print(msg)
                continue

            # Keyword check (flexible)
            required = keyword_checks.get(case["func"], [])
            if required and not validate_keywords_flexible(src, required):
                msg = f" Hidden Test Case {j} Failed: {case['desc']} | Reason: Missing required keyword groups {required}"
                report_lines.append(msg)
                print(msg)
                continue

            input_data = case["input"]
            result = func(input_data) if not isinstance(input_data, tuple) else func(*input_data)

            # expected_func is used to compute expected deterministically when necessary
            if "expected_func" in case and callable(case["expected_func"]):
                # expected_func expects the dataframe arg (first element) for this driver
                expected = case["expected_func"](input_data if not isinstance(input_data, tuple) else (input_data[0]))
            else:
                expected = case["expected"]

            if isinstance(expected, pd.DataFrame):
                pd.testing.assert_frame_equal(
                    result.reset_index(drop=True).fillna(pd.NA),
                    expected.reset_index(drop=True).fillna(pd.NA),
                    check_dtype=False
                )
            else:
                assert result == expected

            msg = f" Hidden Test Case {j} Passed: {case['desc']}"
            report_lines.append(msg)
            print(msg)

        except AssertionError as ae:
            msg = f" Hidden Test Case {j} Failed: {case['desc']} | AssertionError: {ae}"
            report_lines.append(msg)
            print(msg)
        except Exception as e:
            tb = traceback.format_exc()
            msg = f" Hidden Test Case {j} Crashed: {case['desc']} | Error: {e}\n{tb}"
            report_lines.append(msg)
            print(msg)

    # Append run summary to log file
    with open(report_path, "a", encoding="utf-8") as f:
        f.write("\n".join(report_lines) + "\n")


if __name__ == "__main__":
    solution_file = os.path.join(os.path.dirname(__file__), "solution.py")
    test_student_code(solution_file)
